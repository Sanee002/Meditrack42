<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    die("Unauthorized access.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Import CSV – MediTrack</title>
    <style>
        body { font-family: Arial; background: #f4f6f8; padding: 2rem; }
        .box { background: white; padding: 2rem; border-radius: 10px; max-width: 500px; margin: auto; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        h2 { text-align: center; color: #004080; }
        input[type=file], button {
            width: 100%; padding: 10px; margin-top: 1rem; font-size: 16px;
        }
        button { background: #007bff; color: white; border: none; cursor: pointer; }
    </style>
</head>
<body>
    <div class="box">
        <h2>📥 Import Patients CSV</h2>
        <form action="../actions/process_csv.php" method="POST" enctype="multipart/form-data">
            <input type="file" name="csv_file" accept=".csv" required>
            <button type="submit">Upload & Import</button>
        </form>
    </div>
</body>
</html>
