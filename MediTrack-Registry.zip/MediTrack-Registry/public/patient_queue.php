<?php
session_start();
require_once '../config/db.php';

$patients = $pdo->query("SELECT * FROM patient_queue ORDER BY queue_time ASC")->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Patient Queue – MediTrack</title>
    <style>
        /* Use existing styles from dashboard for consistency */
        body { font-family: 'Segoe UI', sans-serif; background: #f4f6f8; padding: 2rem; }
        table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
        th, td { padding: 10px; border-bottom: 1px solid #ddd; }
        th { background: #004080; color: white; }
        button { background: red; color: white; padding: 5px 10px; border: none; cursor: pointer; }
    </style>
</head>                    
<h2>📋 Patient Queue List</h2>

<!-- Add Patient to Queue -->
<form method="POST" action="../actions/add_to_queue.php" style="margin-bottom: 1rem; display: flex; gap: 1rem; flex-wrap: wrap;">
    <input type="text" name="file_number" placeholder="Enter File Number" required style="padding:10px; flex:1; min-width:200px;">
    <input type="text" name="name" placeholder="Enter Patient Name" required style="padding:10px; flex:1; min-width:200px;">
    <button type="submit" style="padding:10px; background:green; color:white; border:none;">➕ Add to Queue</button>
</form>

<!-- Reset Queue -->
<form method="POST" action="../actions/reset_queue.php" onsubmit="return confirm('Clear the entire queue?');" style="margin-bottom: 1.5rem;">
    <button type="submit" style="padding:10px; background:#6c757d; color:white; border:none;">🔄 Reset Queue</button>
</form>


<table>
    <thead>
        <tr>
            <th>Queue #</th>
            <th>File Number</th>
            <th>Name</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $sn = 1; foreach ($patients as $p): ?>
            <tr>
                <td><?= $sn++ ?></td>
                <td><?= $p['file_number'] ?></td>
                <td><?= htmlspecialchars($p['name']) ?></td>
                <td>
                    <form action="../actions/remove_from_queue.php" method="POST">
                        <input type="hidden" name="id" value="<?= $p['id'] ?>">
                        <button type="submit">❌ Remove</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
</body>
</html>
