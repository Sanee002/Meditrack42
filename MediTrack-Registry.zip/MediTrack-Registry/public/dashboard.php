<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user'])) {
    header("Location: ../index.php");
    exit();
}

$user = $_SESSION['user'];
$role = $user['role'];

// Total Patients
$totalStmt = $pdo->query("SELECT COUNT(*) AS total FROM patient_registry");
$totalPatients = $totalStmt->fetch()['total'];

// Single Files
$singleStmt = $pdo->query("SELECT COUNT(*) AS single_count FROM patient_registry WHERE file_type = 'single'");
$singleCount = $singleStmt->fetch()['single_count'];

// Family Files
$familyStmt = $pdo->query("SELECT COUNT(*) AS family_count FROM patient_registry WHERE file_type = 'family'");
$familyCount = $familyStmt->fetch()['family_count'];

// Recent Patients
$recentStmt = $pdo->query("SELECT * FROM patient_registry ORDER BY registration_date DESC LIMIT 10");
$recentPatients = $recentStmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>MediTrack | Dashboard</title>
  <!-- <link rel="stylesheet" href="../assets/css/style.css"> -->
  <style>
body {
  margin: 0;
  font-family: 'Segoe UI', sans-serif;
  background: #f4f6f8;
}

header, nav, footer {
  width: 100%;
  color: white;
}

header {
  background: #004080;
  padding: 1.5rem 2rem;
}

nav {
  background: #003060;
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  padding: 1rem 2rem;
}

nav a {
  color: white;
  background: #004c80;
  padding: 0.5rem 1rem;
  border-radius: 5px;
  text-decoration: none;
}

nav a:hover {
  background: #006699;
}

.container {
  max-width: 1100px;
  margin: 2rem auto;
  padding: 1.5rem;
  background: white;
  border-radius: 10px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.1);
overflow-x: auto;

}

.stats {
  display: flex;
  flex-wrap: wrap;
  gap: 2rem;
  margin-bottom: 2rem;
}

.card {
  flex: 1 1 250px;
  background: #e3f2fd;
  padding: 1rem;
  border-radius: 10px;
  text-align: center;
}

.card h2 {
  margin-bottom: 0.5rem;
  color: #004080;
}

.action-buttons {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-bottom: 1.5rem;
}

.action-buttons a {
  padding: 10px 20px;
  border-radius: 6px;
  text-decoration: none;
  font-weight: bold;
}

.action-buttons .add {
  background: #28a745;
  color: white;
}

.action-buttons .import {
  background: #ffc107;
  color: black;
}

table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 1rem;
  overflow-x: auto;
}

th, td {
  padding: 12px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}

th {
  background-color: #007bff;
  color: white;
}

footer {
  text-align: center;
  padding: 1rem;
  background-color: #002240;
  margin-top: 3rem;
}

/* ✅ Mobile Responsive */
@media (max-width: 768px) {
  header, nav, footer {
    padding: 1rem;
    text-align: center;
  }

  nav {
    flex-direction: column;
  }

  nav a {
    width: 100%;
    text-align: center;
    margin: 5px 0;
  }

  .stats {
    flex-direction: column;
    gap: 1rem;

  }

  .card {
    margin-bottom: 1rem;
    width: 100%;

  }

  .action-buttons {
    flex-direction: column;
    align-items: stretch;
  }

  .container {
    margin: 1rem;
    padding: 1rem;
      overflow-x: auto;

  }

  table {
    font-size: 14px;
    overflow-x: auto;
    display: block;
  }

  table thead {
    display: none;
  }

table tr {
    background: #f9f9f9;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    padding: 10px;
  }

  table td {
    display: flex;
    justify-content: space-between;
    padding: 8px 10px;
    border-bottom: 1px solid #eee;
  }

  table td::before {
    content: attr(data-label);
    font-weight: bold;
    width: 50%;
    color: #555;
  }
    table, th, td {
    font-size: 14px;
    overflow-x: auto;
  }
}

  </style>
</head>
<body>

<header>
  <h1>MediTrack Dashboard</h1>
  <p>Welcome, <?= htmlspecialchars($user['username']) ?> (<?= $user['role'] ?>)</p>
</header>

<nav>
  <a href="dashboard.php">Dashboard</a>
  <?php if ($role === 'admin'): ?>
    <a href="add_patient.php">Add Patient</a>
  <?php endif; ?>
  <a href="view_patients.php">View Patients</a>
  <a href="patient_queue.php">Patient Queue</a>

  <a href="#" onclick="confirmLogout()">Logout</a>

<script>
  function confirmLogout() {
    if (confirm("Are you sure you want to log out?")) {
      window.location.href = "../actions/logout.php";
    }
  }
</script>

</nav>

<div class="container">
  <div class="stats">
    <div class="card">
     <h2>🧾 <?= $totalPatients ?></h2>
      <p>Total Registered Patients</p>
    </div>

    <div class="card">
      <h2><?= $singleCount ?></h2>
      <p>Single Files</p>
    </div>

    <div class="card">
      <h2><?= $familyCount ?></h2>
      <p>Family Files</p>
    </div>
  </div>
<?php if ($role === 'admin'): ?>
  <div class="action-buttons">
    <a href="add_patient.php" class="add">➕ Register New Patient</a>
    <a href="import_excel.php" class="import">📥 Import from Excel</a>
  </div>
<?php endif; ?>


  <h3>📅 Recently Registered Patients</h3>
  <table>
   <thead>
  <tr>
    <th>S/N</th>
    <th>File #</th>
    <th>Name</th>
     <th>Sex</th>
    <th>Type</th>
    <th>Phone</th>
    <th>Address</th>
    <th>Date</th>
  </tr>
</thead>

   <tbody>
<?php $sn = 1; foreach ($recentPatients as $p): ?>
 <tr>
  <td data-label="S/N"><?= $sn++ ?></td>
  <td data-label="File #"><?= htmlspecialchars($p['file_number']) ?></td>
  <td data-label="Name"><?= htmlspecialchars($p['name']) ?></td>
  <td data-label="Sex"><?= htmlspecialchars($p['sex']) ?></td>
  <td data-label="Type"><?= htmlspecialchars($p['file_type']) ?></td>
  <td data-label="Phone"><?= htmlspecialchars($p['phone']) ?></td>
  <td data-label="Address"><?= htmlspecialchars($p['address']) ?></td>
  <td data-label="Date"><?= htmlspecialchars($p['registration_date']) ?></td>
</tr> 

  <?php endforeach; ?>
</tbody>

  </table>
</div>

<footer>
  &copy; <?= date('Y') ?> MediTrack Registry | Powered by ClassicTech Solutionaries
</footer>

</body>
</html>
