<?php
session_start();

// Only admin allowed here
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add New Patient – MediTrack Registry</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f6f8;
        }

        .form-container {
            max-width: 700px;
            margin: 2rem auto;
            padding: 2rem;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 1.5rem;
            color: #004080;
        }

        form {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1rem 2rem;
        }

        form label {
            font-weight: bold;
            margin-bottom: 5px;
            display: block;
            color: #333;
        }

        input[type="text"],
        input[type="date"],
        select,
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        textarea {
            resize: vertical;
        }

        button {
            grid-column: span 2;
            padding: 12px;
            background-color: #007bff;
            color: white;
            font-weight: bold;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        @media (max-width: 768px) {
            form {
                grid-template-columns: 1fr;
            }

            button {
                grid-column: span 1;
            }
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Add New Patient Record</h2>

   <form action="../actions/save_patient.php" method="POST">
    <div>
        <label>File Number (6 digits):</label>
        <input type="text" name="file_number" pattern="\d{6}" placeholder="e.g. 000123" required>
    </div>

    <div>
        <label>Patient Name:</label>
        <input type="text" name="name" required>
    </div>

    <div>
        <label>File Type:</label>
        <select name="file_type" required>
            <option value="single">Single</option>
            <option value="family">Family</option>
        </select>
    </div>

    <div>
        <label>Sex:</label>
        <select name="sex" required>
            <option value="male">Male</option>
            <option value="female">Female</option>
        </select>
    </div>

    <div style="grid-column: span 2;">
        <label>Address:</label>
        <textarea name="address" rows="3" required></textarea>
    </div>

    <div>
        <label>Phone Number:</label>
        <input type="text" name="phone" placeholder="Optional">
    </div>

    <div>
        <label>Date of Registration:</label>
        <input type="date" name="registration_date" required>
    </div>

    <button type="submit">Save Record</button>
</form>

</div>

</body>
</html>
