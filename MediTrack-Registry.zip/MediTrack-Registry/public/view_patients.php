<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user']) || !in_array($_SESSION['user']['role'], ['admin', 'record_officer'])) {
    header("Location: index.php");
    exit();
}

$user = $_SESSION['user'];

// Filters
$filters = [];
$params = [];

if (!empty($_GET['file_number'])) {
    $filters[] = "file_number LIKE ?";
    $params[] = "%" . $_GET['file_number'] . "%";
}
if (!empty($_GET['name'])) {
    $filters[] = "name LIKE ?";
    $params[] = "%" . $_GET['name'] . "%";
}

if (!empty($_GET['sex'])) {
    $filters[] = "sex = ?";
    $params[] = $_GET['sex'];
}

if (!empty($_GET['file_type'])) {
    $filters[] = "file_type = ?";
    $params[] = $_GET['file_type'];
}
if (!empty($_GET['year'])) {
    $filters[] = "YEAR(registration_date) = ?";
    $params[] = $_GET['year'];
}
if (!empty($_GET['phone'])) {
    $filters[] = "phone LIKE ?";
    $params[] = "%" . $_GET['phone'] . "%";
}
if (!empty($_GET['address'])) {
    $filters[] = "address LIKE ?";
    $params[] = "%" . $_GET['address'] . "%";
}


$sql = "SELECT * FROM patient_registry";
if ($filters) {
    $sql .= " WHERE " . implode(" AND ", $filters);
}
$sql .= " ORDER BY registration_date DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$patients = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Patient Records – MediTrack Registry</title>
  <!-- <link rel="stylesheet" href="../assets/css/style.css"> -->
  <style>
   * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', sans-serif;
    background-color: #f4f6f8;
    margin: 0;
}

header {
    background-color: #004080;
    color: white;
    padding: 1rem 2rem;
    width: 100%;
}

header h1 {
    font-size: 22px;
}

header p {
    font-size: 14px;
    margin-top: 5px;
}

nav {
    width: 100%;
    background-color: #003060;
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    padding: 0.8rem 2rem;
}

nav a {
    color: white;
    text-decoration: none;
    font-weight: bold;
    padding: 0.5rem 1rem;
    border-radius: 4px;
    background-color: #004c80;
    transition: background 0.3s ease;
}

nav a:hover {
    background-color: #006699;
}

.container {
    max-width: 1100px;
    margin: 1.5rem auto;
    background-color: white;
    padding: 1.5rem;
    border-radius: 8px;
    box-shadow: 0 0 6px rgba(0,0,0,0.1);

    
}

form label {
    font-weight: bold;
    display: block;
    margin-top: 1rem;
}

form input, form select {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.form-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 1rem 2rem;
}

@media (max-width: 768px) {
  .form-grid {
    grid-template-columns: 1fr;
  }
}


form button {
    margin-top: 1.5rem;
    padding: 10px 20px;
    background-color: #007bff;
    border: none;
    color: white;
    border-radius: 5px;
    cursor: pointer;
}

form button.clear {
    background-color: #6c757d;
    margin-left: 10px;
}

table {
    width: 100%;
    margin-top: 2rem;
    border-collapse: collapse;
}

th, td {
    padding: 12px;
    border-bottom: 1px solid #eee;
    text-align: left;
}

th {
    background-color: #007bff;
    color: white;
}

footer {
    width: 100%;
    text-align: center;
    padding: 1rem;
    background-color: #002240;
    color: white;
    margin-top: 2rem;
}

/* 📱 Responsive */
@media (max-width: 768px) {
    nav {
        flex-direction: column;
    }

    nav a {
        width: 100%;
        text-align: center;
    }
  table thead {
    display: none;
  }
    .container {
        margin: 1rem;
        padding: 1rem;
    }

    
  table tr {
    display: block;
    margin-bottom: 1.2rem;
    border-bottom: 2px solid #ccc;
    background: #f9f9f9;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
  }

    table td {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px;
    border-bottom: 1px solid #eee;
  }

  table td::before {
    content: attr(data-label);
    font-weight: bold;
    color: #555;
    width: 50%;
    flex-shrink: 0;
  }

    table td:last-child {
    border-bottom: none;
  }
    table, th, td {
        font-size: 14px;
    }

    header h1 {
        font-size: 18px;
    }

    header p {
        font-size: 12px;
    }
}

  </style>
</head>
<body>

<header>
  <h1>MediTrack Registry</h1>
  <p>Welcome, <?= htmlspecialchars($user['username']) ?> (<?= $user['role'] ?>)</p>
</header>

<nav>
  <a href="dashboard.php">Dashboard</a>
  <?php if ($user['role'] === 'admin'): ?>
      <a href="add_patient.php">Add New Patient</a>
  <?php endif; ?>
  <a href="view_patients.php">View Patients</a>
    <a href="patient_queue.php">Patient Queue</a>
 <a href="#" onclick="confirmLogout()">Logout</a>

<script>
  function confirmLogout() {
    if (confirm("Are you sure you want to log out?")) {
      window.location.href = "../actions/logout.php";
    }
  }
</script>

</nav>

<div class="container">
  <h2>Search Patient Records</h2>

  <form class="search-form" method="GET" action="view_patients.php">
  <div class="form-grid">
    <div>
      <label>File Number:</label>
      <input type="text" name="file_number" value="<?= htmlspecialchars($_GET['file_number'] ?? '') ?>">
    </div>

    <div>
      <label>Name:</label>
      <input type="text" name="name" value="<?= htmlspecialchars($_GET['name'] ?? '') ?>">
    </div>

    <div>
      <label>File Type:</label>
      <select name="file_type">
        <option value="">-- All --</option>
        <option value="single" <?= ($_GET['file_type'] ?? '') === 'single' ? 'selected' : '' ?>>Single</option>
        <option value="family" <?= ($_GET['file_type'] ?? '') === 'family' ? 'selected' : '' ?>>Family</option>
      </select>
    </div>

    <div>
      <label>Registration Year:</label>
      <input type="number" name="year" min="2000" max="2099" value="<?= htmlspecialchars($_GET['year'] ?? '') ?>">
    </div>

    <div>
      <label>Phone Number:</label>
      <input type="text" name="phone" value="<?= htmlspecialchars($_GET['phone'] ?? '') ?>">
    </div>

    <div>
      <label>Address:</label>
      <input type="text" name="address" value="<?= htmlspecialchars($_GET['address'] ?? '') ?>">
    </div>
  </div>

  <div style="margin-top: 1rem;">
    <button type="submit">Search</button>
    <a href="view_patients.php"><button type="button" class="clear">Clear</button></a>
  </div>
</form>


  <h3><?= count($patients) ?> Record(s) Found</h3>
  <div style="overflow-x: auto;">

  <table>
<thead>
  <tr>
    <th>S/N</th>
    <th>File #</th>
    <th>Name</th>
    <th>Sex</th>
    <th>Type</th>
    <th>Phone</th>
    <th>Address</th>
    <th>Registration Date</th>
    <th>Queue</th>
  </tr>
</thead>
<tbody>
      <?php if (count($patients)): ?>
<?php $sn = 1; foreach ($patients as $p): ?>
 <tr>
  <td><?= $sn++ ?></td>
  <td data-label="File #"><?= htmlspecialchars($p['file_number']) ?></td>
  <td data-label="Name"><?= htmlspecialchars($p['name']) ?></td>
  <td data-label="Sex"><?= htmlspecialchars($p['sex']) ?></td>
  <td data-label="Type"><?= htmlspecialchars($p['file_type']) ?></td>
  <td data-label="Phone"><?= htmlspecialchars($p['phone']) ?></td>
  <td data-label="Address"><?= htmlspecialchars($p['address']) ?></td>
  <td data-label="Registration Date"><?= htmlspecialchars($p['registration_date']) ?></td>
  <td>
    <form action="../actions/add_to_queue.php" method="POST" style="display:inline;">
      <input type="hidden" name="file_number" value="<?= htmlspecialchars($p['file_number']) ?>">
      <input type="hidden" name="name" value="<?= htmlspecialchars($p['name']) ?>">
      <button type="submit" style="padding: 6px 10px; font-size: 14px; background: green; color: white; border: none; border-radius: 4px;">
        ➕ Queue
      </button>
    </form>
  </td>
</tr>

  <?php endforeach; ?>

      <?php else: ?>
        <tr><td colspan="6">No records found.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
  </div>
</div>

<footer>
  &copy; <?= date('Y') ?> MediTrack Registry | Powered by ClassicTech Solutionaries
</footer>

</body>
</html>
