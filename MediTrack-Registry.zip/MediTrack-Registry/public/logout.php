<a href="../actions/logout.php">Logout</a>
